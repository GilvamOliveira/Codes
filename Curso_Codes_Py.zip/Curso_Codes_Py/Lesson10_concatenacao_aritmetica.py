concatenacao = 'A' + 'B' + 'C'
print(concatenacao)

concatenacao_nome = 'Gilvam' + ' ' + 'Júnior' + ' ' + str(10)  #concatenação somente em string(str)
print(concatenacao_nome)

j_dez_vezes = 'J' * 10
tres_vezes_junior = 3 * 'Junior'
print(j_dez_vezes)
print(tres_vezes_junior)
