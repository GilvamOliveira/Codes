# conversão de tipos, coerção
# type conversation, typecasting, coercion
# é o ato de converter um tipo em outro
# tipos imutáveis e primitivos:
# str, int, float, bool
print(1 + 1.1)
print('a' + 'b')
print(int('1'), type(int('1')))
print(int('1') + 1)
print(float('1.2') + 1)
print(type(float('1.2') + 1))
print(bool(' '))
print(str(11) + 'g')
