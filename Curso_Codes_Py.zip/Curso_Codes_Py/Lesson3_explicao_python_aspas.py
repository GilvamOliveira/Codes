'''
Docstring
Python = Linguagem de Programação 
Tipo de tipagem = Dinâmica / Forte 
Dinâmica = entende o dado sem precisar informá-lo.
Estático = necessário explicar qual o dado está sendo inserido.
str -> string -> texto
Strings são textos que estão dentro das aspas
'''
print(1234)

# Aspas simples
print('Gilvam Júnior')
print(1, 'Gilvam "Júnior"')

# Aspas duplas
print("Júnior Oliveira")
print(2, "Júnior 'Oliveira'")

# Escape
print("Júnior \"Oliveira\"")

# r
print(r'Gilvam \'Júnior\'')
