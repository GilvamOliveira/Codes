"""
DocString, utilizados para anotações nesse caso utilizando as " 3x
"""
'''
DocString, utilizados para anotações nesse caso utilizando as ' 3x
'''

# Permite adicionar/escrever um comentário
print ('Hello, world!') # Pode vir a frente
# Pode vir abaixo
