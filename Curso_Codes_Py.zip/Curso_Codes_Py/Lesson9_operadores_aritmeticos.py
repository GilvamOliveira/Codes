adicao = 10 + 10 
print('\nAdição:', adicao)

subtracao = 10 - 5 
print('\nSubtração:', subtracao)

multiplicacao = 10 * 10
print('\nMultiplicação: ', multiplicacao)

divisao = 10 / 2.2  #float
print('\nDivisão:', divisao)

divisao_inteira = 10 // 2.2  
print('\nDivisão inteira:', divisao_inteira)

exponenciacao = 2 ** 10
print('\nExponenciação:', exponenciacao)

modulo = 55 % 2  # resto da divisão
print('\nMódulo:', modulo)

print(10 % 8 == 0)
print(16 % 8 == 0)

if (20 % 2 == 0):
    print('Par')
else:
    print('Ímpar')


